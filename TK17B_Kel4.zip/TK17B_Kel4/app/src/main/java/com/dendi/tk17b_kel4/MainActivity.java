package com.dendi.tk17b_kel4;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.lang.reflect.Array;

public class MainActivity extends AppCompatActivity {

    private EditText nama, jam;
    private Spinner kecepatan;
    private RadioGroup status;
    private RadioButton member;
    private Button hitung, keluar;


    @Override

    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nama = findViewById(R.id.editText1);
        jam = findViewById(R.id.editText2);
        status = findViewById(R.id.radioGroup3);
        kecepatan = findViewById(R.id.spinner1);
        hitung = findViewById(R.id.btn_hitung);
        keluar = findViewById(R.id.btn_keluar);

        hitung.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                String speed, kat_kecepatan, sts_member;
                int harga = 0;
                int selectedId;
                int jumlah_jam;
                double total, potongan = 0, diskon, jumlah_bayar;
                boolean isEmptyFields = false;
                boolean isInvalidDouble = false;


                if (TextUtils.isEmpty(nama.getText().toString())) {
                    isEmptyFields = true;
                    nama.setError("Field ini tidak boleh kosong");
                }
                if (TextUtils.isEmpty(jam.getText().toString().trim())) {
                    isEmptyFields = true;
                    jam.setError("Field ini tidak boleh kosong");
                }
                jumlah_jam = Integer.parseInt(jam.getText().toString());
                speed = kecepatan.getSelectedItem().toString();
                selectedId = status.getCheckedRadioButtonId();
                member = findViewById(selectedId);
                if (speed.equals("Super")) {
                    harga = 10000;
                    if (jumlah_jam > 10) {
                        potongan = 0.1;
                    }
                } else if (speed.equals("Midle")) {
                    harga = 7500;
                    if (jumlah_jam > 8) {
                        potongan = 0.07;
                    }
                } else if (speed.equals("Low")) {
                    harga = 5000;
                    if (jumlah_jam > 5) {
                        potongan = 0.05;
                    }
                }

                if (member.getText().equals("Member")) {
                    harga = 5000;
                    potongan = 0;
                }

                total = (harga * jumlah_jam);
                diskon = (total * potongan);
                jumlah_bayar = total - diskon;

                Toast.makeText(getApplicationContext(), " Nama Pengguna :" + nama.getText().toString() + ", Status : " + member.getText() + ", Kategori : " + speed + ",  Harga/Jam : " + harga + ", Jumlah jam : " + jumlah_jam + ", Potongan : " + potongan * 100 + "% , Total Harga : " + jumlah_bayar, Toast.LENGTH_SHORT).show();

            }


        });

        keluar.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                showDialog();
            }


        });



    }
    private void showDialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);

        // set title dialog
        alertDialogBuilder.setTitle("Keluar dari aplikasi?");

        // set pesan dari dialog
        alertDialogBuilder
                .setMessage("Klik Ya untuk keluar!")
                .setIcon(R.mipmap.ic_launcher)
                .setCancelable(false)
                .setPositiveButton("Ya",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        // jika tombol diklik, maka akan menutup activity ini
                        MainActivity.this.finish();
                    }
                })
                .setNegativeButton("Tidak",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // jika tombol ini diklik, akan menutup dialog
                        // dan tidak terjadi apa2
                        dialog.cancel();
                    }
                });

        // membuat alert dialog dari builder
        AlertDialog alertDialog = alertDialogBuilder.create();

        // menampilkan alert dialog
        alertDialog.show();
    }
}
